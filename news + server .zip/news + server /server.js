const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

const db = new sqlite3.Database('./news.db');

db.run(`
    CREATE TABLE IF NOT EXISTS posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        date TEXT NOT NULL,
        timestamp INTEGER NOT NULL
    )
`);

app.get('/api/posts', (req, res) => {
    db.all('SELECT * FROM posts ORDER BY timestamp DESC', [], (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        res.json(rows);
    });
});
app.post('/api/posts', (req, res) => {
    const { title, content } = req.body;
    if (!title || !content) {
        res.status(400).json({ error: "Заголовок та текст обов'язкові"});
        return;
    }
    const date = new Date().toLocaleString('uk-UA');
    const timestamp = Date.now();
    db.run(
        'INSERT INTO posts (title, content, date, timestamp) VALUES (?, ?, ?, ?)',
        [title, content, date, timestamp],
        function(err) {
            if (err) {
                res.status(500).json({ error: err.message });
                return;
            }
            res.json({
                id: this.lastID,
                title,
                content,
                date,
                timestamp
            });
        }
    );
});
app.delete('/api/posts/:id', (req, res) => {
    const id = req.params.id;
    
    db.run('DELETE FROM posts WHERE id = ?', [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
            return;
        }
        
        if (this.changes === 0) {
            res.status(404).json({ error: 'Допис не знайдено' });
            return;
        }
        
        res.json({ message: 'Допис видалено', id: id });
    });
});
app.listen(PORT, () => {
    console.log(`Сервер запущено на http://localhost:${PORT}`);
});