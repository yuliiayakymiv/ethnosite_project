const API_URL = 'http://localhost:3000/api';
function getFormData() {
    return {
        title: document.getElementById('title').value,
        content: document.getElementById('content').value
    };
}

async function savePost(post) {
    const response = await fetch(`${API_URL}/posts`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(post)
    });
    
    if (!response.ok) {
        throw new Error('Помилка при збереженні');
    }
    
    return await response.json();
}
async function getPosts() {
    const response = await fetch(`${API_URL}/posts`);
    
    if (!response.ok) {
        throw new Error('Помилка при отриманні дописів');
    }
    
    return await response.json();
}
async function deletePost(id) {
    const response = await fetch(`${API_URL}/posts/${id}`, {
        method: 'DELETE'
    });
    
    if (!response.ok) {
        throw new Error('Помилка при видаленні');
    }
    
    return await response.json();
}
function createPostElement(post) {
    const postDiv = document.createElement('div');
    postDiv.style.border = '1px solid #ccc';
    postDiv.style.padding = '10px';
    postDiv.style.marginBottom = '10px';
    postDiv.innerHTML = `
        <h3>${escapeHtml(post.title)}</h3>
        <p>${escapeHtml(post.content)}</p>
        <small>${post.date}</small>
        <br>
        <button onclick="handleDelete(${post.id})">Видалити</button>
    `;
    
    return postDiv;
}
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
function displayPosts(posts) {
    const container = document.getElementById('postsContainer');
    container.innerHTML = '';
    
    if (posts.length === 0) {
        container.innerHTML = '<p>Поки що немає дописів. Додайте перший!</p>';
        return;
    }
    posts.forEach(post => {
        container.appendChild(createPostElement(post));
    });
}
async function loadPosts() {
    try {
        const posts = await getPosts();
        displayPosts(posts);
    } catch (error) {
        console.error('Помилка:', error);
        alert('Не вдалося завантажити дописи');
    }
}
async function handleDelete(id) {
    if (!confirm('Видалити цей допис?')) {
        return;
    }
    
    try {
        await deletePost(id);
        await loadPosts();
        alert('Допис видалено!');
    } catch (error) {
        console.error('Помилка:', error);
        alert('Не вдалося видалити допис');
    }
}
async function handleFormSubmit(event) {
    event.preventDefault();
    
    const formData = getFormData();
    if (!formData.title.trim() || !formData.content.trim()) {
        alert('Заповніть всі поля!');
        return;
    }
    
    try {
        await savePost(formData);
        document.getElementById('postForm').reset();
        await loadPosts();
        alert('Допис додано!');
    } catch (error) {
        console.error('Помилка:', error);
        alert('Не вдалося додати допис');
    }
}
window.handleDelete = handleDelete;
document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('postForm');
    form.addEventListener('submit', handleFormSubmit);
    loadPosts();
});